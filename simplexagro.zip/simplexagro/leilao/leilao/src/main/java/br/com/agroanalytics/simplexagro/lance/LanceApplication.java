package br.com.agroanalytics.simplexagro.lance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LanceApplication.class, args);
	}

}
