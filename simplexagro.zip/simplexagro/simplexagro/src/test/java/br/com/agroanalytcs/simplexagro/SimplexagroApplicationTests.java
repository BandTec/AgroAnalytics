package br.com.agroanalytcs.simplexagro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplexagroApplicationTests {

	@Test
	void contextLoads() {
	}

}
